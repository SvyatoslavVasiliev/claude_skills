# Opportunity artifact

Answers one question: **why is this the most important thing to work on?** No solutions here. If a solution sneaks in, cut it and note it belongs to the next stage.

## The potential model — read this first

A low metric is not a problem. Growing a metric is not a potential. "Retention 18%, поднимем до 30%, получим +X MAU" is empty — it works for any conversion metric and proves nothing. Real potential is derived, not asserted:

```
Ceiling      = frequency of the underlying need        (analogous to TAM)
Reachable    = Ceiling − barriers                       (the real potential)
```

and the reachable part is only credible if you answer three questions *with evidence*, not assertion:

1. **What concrete barriers** stop users from using the product more often?
2. **How many users hit each barrier** (the volume)?
3. **How do we know** that removing the barrier raises frequency — i.e. the causal link, not a guess?

Achievability cannot be postulated. "Target 30% because a benchmark says 30%" is still weak unless 30% is derived from the need's frequency and the removable barriers.

### The ceiling looks OUTWARD, not at your current base

The frequency-of-need ceiling is a **market** quantity — how many people in the target geographies have this need/scenario at all — NOT how many of your current users already do it. A potential computed from users who *already demonstrate the behavior* is survivorship (A3) baked into the framing: it under-states the lever and hides it inside retention.

### Use a TAM/SAM/SOM lattice — but SOM here means the target, not today's penetration

Frame potential as layers, with one redefinition that matters: **SOM is not current penetration — it's the audience we set out to capture.** This is not the textbook reading; use this one.

```
TAM = market with the need              (people in target geos who have the scenario)
SAM = ∩ with our user base
Reachable slice = users who TRY the scenario with us but FAIL because of a *named* barrier
                  (NOT the whole market; and the already-converted are EXCLUDED, not counted)
SOM = (size of the reachable slice) × (expected conversion from our solution)
    = the share of the barrier-blocked users we are committing to retain → this becomes the KR
```

So the already-engaged who close the need today are *not* SOM and *not* the target — they're excluded. The target is the blocked slice, and SOM is the goal we set on it: how many of the people who abandon *because of the barrier* we intend to keep in the flow. That number is the one that should show up as the Key Result.

The framing must point at the **segment most sensitive to the lever** within that slice — and state its **volume** in the same breath (focus without its size is incomplete, B2). A big but unresponsive segment is not the potential; a sensitive but tiny one may not be worth it — you need both the sensitivity and the count.

Tell: if "SOM" is described as "who uses it today," it's mis-framed — that's survivorship, and it hides the lever inside retention. Effect is measured on a product-wide metric (minutes/user, trips/user, completed-baskets/user), not sub-sample survival. Numbers from the current base are tagged and paired with a market analog.

## Structure

```
# Opportunity: [short name]

## Потенциал
- TAM: рынок с потребностью в целевых гео
- SAM: пересечение с нашей базой
- Достижимый слой = те, кто пробует сценарий у нас, но бросает из-за [барьер]
  (уже-сконвертившиеся ИСКЛЮЧЕНЫ, не считаются)
- SOM = объём достижимого слоя × ожидаемая конверсия решения = будущий KR
- Самый чувствительный к рычагу сегмент внутри слоя + его ОБЪЁМ (фокус без числа неполон)
- Доказательство, что снятие барьера повышает частоту (+ качественное подтверждение барьера)
- Эффект мерить продуктовой метрикой (минуты/юзер), не выживаемостью подвыборки

## Сегмент
- Определяющий признак = переменная будущей гипотезы (не косвенный прокси)
- Поведенческое определение: что делает, в каком контексте, как часто
- Почему именно этот сегмент (обоснование фокуса, следует из потенциала)
- Объём: доля в MAU / GMV / orders
- Аналитическое определение: каждый термин операционализирован

## Проблема
- Декомпозиция явления на наблюдаемое ДО объяснений (стороны, фазы, сегменты)
- Что болит (наблюдаемое поведение, не интерпретация)
- Почему именно эта проблема (обоснование фокуса)
- Чем подтверждено: данные / интервью / поведение [ссылка или OPEN]
- Альтернатива, которой пользуются сейчас

## Статус доказательств
| Утверждение | факт / корреляция / интерпретация | proven / disproven / assumed |

## [OPEN] — что проверить, чтобы закрыть гейт
```

## Gate to pass before Solution stage

- Potential is **derived** (ceiling − barriers, with volume and a causal-link check per barrier), not asserted as current→target. Missing pieces are marked `[OPEN]`, not invented.
- Segment's **defining trait is the hypothesis variable** (not an indirect proxy), is behavioral, has a justified focus, and every term is operationalized.
- The problem is **decomposed into observables before any explanation**, separated from interpretation, with a justified focus.
- Every causal claim tagged fact / correlation / assumption.

## Good vs bad

**Potential — bad:** "D30 новичков 18% → поднимем до 30%, это +X MAU."
Why: low metric ≠ problem; growth ≠ potential; achievability postulated.
**Potential — good:** "Потребность 'слушать в дороге' возникает ~daily у [сегмента] (потолок). Барьер: музыка рвётся в зонах слабой сети. Объём: 14% MAU регулярно попадают в такие зоны [метрика связи]. Связь с частотой: [OPEN — нужно сравнение behavior-matched когорт с/без обрывов]. Пока link не доказан — потенциал помечен как гипотетический."

**Segment — bad:** "Слушали в дороге 8+ сессий И не скачивали ни трека." (proxy bundle; "не скачивал" объясняется чем угодно)
**Segment — good:** "Пользователи с частым попаданием в условия слабого сигнала: [операционализация — что такое частое, как детектируем плохую связь]. Признак сегмента = переменная гипотезы об обрывах."
