# OKR quality bar

OKRs are the preferred goal frame, but most are weak because the language is lazy. The hard part is linguistic, and that's where the discipline lives.

## Where the OKR sits in the flow

The OKR is the **metric focus at the *entry* of the planning cycle, justified by the market potential** — not a wrapper around a solution you've already picked. It is fixed on the **reachable slice** from the Opportunity stage; the KR expresses the **target conversion of that slice (the SOM)**. Solutions are *hypotheses/initiatives inside the cycle* that compete *under* the KR and come *after* it.

So the KR must be phrased so the **whole fan of candidate solutions** could move it — not just one. If only one specific solution could satisfy a KR, that KR is the solution's output in disguise. Example: Objective "любой рецепт можно приготовить сегодня"; a KR "доля рецепт-корзин без 'не нашлось' до 80%" silently commits to *one class* of solution (improve availability) and excludes equally-valid levers — delivery integration, hiding offending recipes, showing substitutes — that solve the problem without touching "находимость." The result-level KR ("+31К/мес возвращающихся к готовке после 'не нашлось'") is correct: every solution in the fan competes to move it.

## Objective — the bar

An Objective describes a **desired state / shift in how the product is perceived**, in plainly accessible language, such that its ambition and *why it matters* are self-evident from the wording. Not a metric, not a task.

But a well-phrased state is an empty check until three things exist behind it (this is the hard gate):

1. **A measurement approach** — how the state is measured at all.
2. **A clear growth lever** — what actually moves it.
3. **A metric or metric-group** — the concrete gauge(s).

And: **comparative claims** ("стать №1", "лучший по X") require a *single shared scale* on which that comparison even exists. "№1 по качеству рекомендаций" is a slogan unless there's a cross-player ranking scale for recommendation quality.

Also: **why this objective and not another?** An Objective with no justified focus is defective. If the business logic is "leadership in X → win market," then the goal must ultimately be measured in market terms (see KR rule below).

Test: read it aloud. A smart outsider should get *why it matters* from the sentence alone — and you should be able to point to the measurement, the lever, and the metric.

**Bad:** "Увеличить DR до 90%." (metric, not objective)
**Bad:** "Улучшить качество доставки." (vague; no ambition, no why)
**Bad:** "Стать №1 по качеству рекомендаций." (comparative claim, no shared scale, no lever, no metric → slogan)
**Good:** "Сделать доставку настолько надёжной, что бизнес строит на ней процессы." (end state; ambition + why visible; KR carries the number; lever and metric exist behind it)

## Key Result — the bar

A KR is **concrete, complementary, ambitious, and connected to the main metrics**. The decisive, most-missed rule:

**A KR measures the END RESULT the Objective promises — not a mid-chain proxy of the mechanism.**

Topic-match is not enough; *level*-match is required. If the Objective is about market leadership, KRs about engagement-with-recommendations are wrong: quality can rise while market share and brand perception don't move. Either the KRs measure the market outcome, or the Objective is honestly rewritten to be about engagement.

A good KR: concrete and measurable (no "improve"/"better"); complements *this* Objective; ambitious (no sandbag); transparent line to a top metric; and sits at the *same point on the causal chain* as the Objective's promised end.

**Bad:** "Поднять удовлетворённость." (not measurable)
**Bad:** "Запустить trusted-фильтр." (output/task, not a result)
**Bad (level mismatch):** Objective про лидерство на рынке + KR про долю прослушанных из рекомендаций. (mid-chain proxy)
**Good:** "Aggregated DR бизнес-сегмента ≥ 90% в топ-5 городах (сейчас 80%), доля бизнес-юзеров с 2+ попытками на заказ < 10% (сейчас ~90%)."

## Failures to flag

- **Objective is a metric / a task** → rewrite as a state; move number to KR.
- **Objective lacks measurement / lever / metric** → it's a slogan (F1).
- **Comparative claim with no shared scale** → no basis for "№1".
- **No justified focus** → why this objective?
- **KR is an output/activity** ("сделать", "запустить").
- **KR at mid-chain, Objective at end** → level mismatch, fatal (F2).
- **No line to a top metric / sandbagged KR.**

Always check Objective and KRs *together*: the most common real failure is a fine Objective paired with KRs that quietly measure a mid-chain proxy.
