# Experiment artifact

Answers: **how will we know if we were right — and what will we have learned about *why*?** The bar is falsifiability, pre-registration, AND mechanism extraction. An experiment that confirms an effect without yielding transferable understanding is incomplete.

## Structure

```
# Experiment: [hypothesis name]

## Гипотеза в проверяемой форме
Мы верим, что для [сегмента] [решение] приведёт к [измеримому изменению],
потому что [механизм]. Узнаем по [метрике]. Порог: [значение].
(Признак сегмента = переменная гипотезы. Обе переменные операционализированы,
включая зависимую — churn через ранние предикторы, не абстракцию. C2/C3)

## Как проверяем
Конкретный метод: какое сравнение, на каких данных, какой срез, период.
Контроль = match по поведению МИНУС исследуемый фактор (изоляция одного
фактора). Пример: retention 1-й→2-й Accept, окно неделя/месяц/полгода,
trusted vs untrusted в 0-й день (0-й день делает выбор экзогенным — A3).

## Что изолирует механизм
Почему тест отделяет заявленную причину от альтернатив. Какие конфаундеры
контролируются. Где риск селекции (A3) и как он снят.

## Контр-метрики (обязательно)
Кому ещё показывается / кого затрагивает? Не ухудшили ли опыт другим
сегментам (старичкам и т.п.)? Эффект не должен быть оплачен ухудшением рядом.

## Порог решения (pre-registered, ДО эксперимента)
go / no-go / pivot — числа зафиксированы до запуска. Любая пост-фактум
переинтерпретация порога — флаг.

## Извлекаемый механизм (обязательно)
Что узнаем о ТОМ, ПОЧЕМУ сработало, и сможем переиспользовать дальше?
Что смыслово заложено в выигравший вариант? (A4)

## Декомпозиция ценности (после результата)
Что именно в решении работает, по какому принципу конвертит лучше?
Зеркально: что ЛИШНЕЕ — что убрать без потери метрик? (что будет при
сокращении до минимума?) Рычаг роста НЕ экстраполировать линейно из
разового эффекта; проверить контакт с реальностью носителя. (D3)

## Результат
| Гипотеза | Как проверяем | Доказано / Опровергнуто / assumed |
```

## Gate (the bar to actually run / to call it done)

- Hypothesis **falsifiable**: there's a stated result that proves it *wrong*.
- Threshold **pre-registered** before the run.
- Test **isolates the mechanism** and rules out selection (A3), not mere correlation.
- Control = **behavior-matched minus the studied factor** (one factor isolated).
- **Counter-metrics** present — effect not paid for by harm elsewhere.
- Both variables **operationalized**, including churn via predictors.
- On completion: **mechanism extracted** ("why") and **value decomposed** (what works / what's removable) — not just "the metric moved."

## Why the extras matter

**Mechanism (A4):** a stat-sig win with no extracted "why" leaves nothing to reuse. "+5pp, раскатываем" is half an experiment. Ask what meaning the winning variant encoded.

**Counter-metrics:** "+5pp D30" is not a result until you know it didn't cost retention/experience for another group.

**Lever ≠ extrapolation (D3):** "20 треков дали +5pp → 50 треков дадут больше" assumes linearity and ignores that 20 don't fit on screen. A lever is not proven by a one-off effect.

**Value decomposition:** after a win, ask which component carries the value and what's dead weight — cut to 5 треков, do metrics survive? This is decomposition-after-experiment, mirroring decomposition-before-hypothesis on the opportunity side.

## Good vs bad

**Good:** "Если новичку в 0-й день попался trusted-исполнитель, retention во 2-й Accept выше, чем у получившего untrusted. Метод: две behavior-matched когорты, окно нед/мес/полгода. 0-й день делает выбор экзогенным. Контр-метрика: не просел ли done-rate у untrusted-курьеров без потока новичков. Механизм на проверке: trust снижает раннюю фрустрацию — переносимо на онбординг."
**Bad:** "Trusted улучшают опыт, ждём рост retention." (нет порога, метода, контроля, контр-метрик, механизма, исхода-опровержения)
