# Anti-patterns library

Consult this during every critique. Each entry: the trap → how it shows up → the question that exposes it. Distilled from real discovery work; they recur constantly. The critique names only the traps that actually apply to the artifact in front of you.

## A. Causation & evidence

### A1. Correlation dressed as causation
**Shows up as:** "X coincides with Y, therefore X causes Y." E.g. "MR упал, EGP упал вдвое → кризис уронил MR."
**Expose it:** What else could explain Y? Has the link been checked or just narrated? Find a case where X happened and Y didn't.

### A2. Interpretation labeled as fact
**Shows up as:** a cancellation reason, survey label, or support tag treated as the underlying truth. "Причина 'долго ждать' → значит нарушаем ETA."
**Expose it:** Observed signal or your reading of it? Decompose into separate checkable claims (курьер реально не ехал? ожидание дольше обещанного ETA? у выбравших trusted меньше?).

### A3. Selection / survivorship in the evidence
**Shows up as:** "users who do X have better metrics," where doing X is itself a marker of an already-better user. "Скачавшие реже чернят" / "выбравшие trusted имеют выше retention."
**Expose it:** Is X causing the outcome or selecting users who'd have it anyway? Can X be made exogenous — e.g. compare behavior-matched cohorts, or look only at a user's 0-day before they could self-select?

### A4. "Proven by experiment" with no mechanism extracted
**Shows up as:** a stat-sig A/B win declared as done. "Плейлист дал +5pp D30, раскатываем."
**Why it's a trap:** the test confirmed an *effect* but produced no transferable understanding of *why*. Nothing to reuse in the next decision.
**Expose it:** What did we learn about *why* it worked that we can carry forward? What meaning was encoded in the winning variant? If the answer is "it just worked," the experiment is incomplete.

## B. Focus & framing

### B1. Low metric called a problem / metric growth called potential
**Shows up as:** "retention низкий — вот проблема; поднимем до 30% — вот потенциал." Works for any conversion metric and means nothing.
**Expose it:** Potential is not "current → target." It's *frequency of the underlying need* (the ceiling, like TAM) minus the barriers, with evidence at each link. What barriers stop more frequent use? How many users hit them? How do we know removing them raises frequency?

### B1b. Potential computed from the current base (survivorship in the framing)
**Shows up as:** ceiling and segment size derived from users who *already* do the behavior; effect measured as retention of that sub-sample. "3.1М ночных слушателей, потолок ежедневный, они churn-ят на 22% чаще." / "80К коммьютеров, LTV×3, churn-ят вдвое чаще."
**Why it's a trap:** the lever (converting the try-but-fail slice) is hidden inside retention of the survivors; the ceiling is under-stated.
**Expose it:** Lay out TAM (market with the need) / SAM (∩ our base) / SOM (who closes it regularly today). The reachable potential is **SAM − SOM narrowed to "try but fail because of [named barrier]"** — not the whole market, not the survivors. Which segment in that slice is *most sensitive* to the lever? Measure effect on a product-wide metric, not sub-sample survival.

### B2. Unjustified focus
**Shows up as:** a problem, segment, or objective chosen with no argument for *why this one*. "Новички churn-ят" / "в фокусе отмены" / "стать №1 по рекомендациям."
**Expose it:** Why this and not something else? The choice must follow from the quantified potential, not be asserted. This applies at every level: problem, segment, Objective.

### B3. Phenomenon not decomposed before hypothesizing
**Shows up as:** a hypothesis about a cause before the phenomenon is split into observable parts. "Курьеры отменяют → покажем чаевые" — but whose cancels (courier/client)? at which phase?
**Expose it:** Decompose the phenomenon into observable components (funnel stages, sides, segments) *before* explaining it. A hypothesis without prior decomposition is premature.

### B4. Solution broad-spectrum = loss of focus
**Shows up as:** a solution promoted *because* it hits several problems at once. "Решение 1 закрывает A и B — поэтому приоритет."
**Why it's a trap:** hitting many problems at once usually means hitting none precisely. Breadth is a red flag, not a merit.
**Expose it:** Map allows one-to-many in *either* direction separately (one problem → many candidate solutions, OR one solution → many problems). But "many problems → one solution" as a *priority argument* is forbidden — it blurs focus.

## C. Operationalization

### C1. Unoperationalized term / threshold / label
**Shows up as:** "новички", "частое попадание в плохую связь", "под вкус", "активные", "34% сессий без брони" — used without an analytical definition.
**Expose it:** How is this measured, exactly? What criteria? Does "новички" include returning users? Every term, threshold, and label must be measurable, or the framing isn't ready.
**Then go further — does the number even support the claimed problem?** Operationalization is not the goal; it's a tool to check the problem *exists in the numbers*. "34% сессий без брони" → that's a 66% booking conversion — is 66% actually bad? On what basis do we think we can do better? Cracking open a vague term often (a) reveals a hidden hole (e.g. "под вкус" for new users → cold start) or (b) shows the stated problem doesn't survive its own number.

### C2. Outcome variable left abstract
**Shows up as:** "снизит отток", "повысит retention" with no definition of the variable.
**Expose it:** How is churn defined operationally? Via which observable event, which early predictors? (Cf. churn-1 = 2 weeks no app-open; churn-2 = 2 weeks no order-form-view.) Both independent and dependent variables get operationalized.

### C3. Segment built from indirect proxies, not the hypothesis variable
**Shows up as:** a segment defined by a bundle of behaviors that *seem* related. "Слушали в дороге 8+ сессий И не скачивали ни трека" — and so what? "Не скачивал" has many explanations.
**Expose it:** The segment's defining trait must *be* the hypothesis variable. If the hypothesis is about poor connectivity, define the segment by connectivity exposure — not by proxies whose link to the problem is unargued. Segment and hypothesis must be mirror images.

## D. Volume & scale

### D1. Problem volume unchecked
**Expose it:** How many users does this problem actually touch? Share of MAU / GMV / orders?

### D2. Lever reach unchecked (separate from D1)
**Shows up as:** a causally-valid lever that can only fire on a tiny slice. "Чаевые снизят отмены" — but чаевые есть лишь в 1% заказов.
**Expose it:** Even if the lever works, on what share of cases *can* it work? A causally-true lever with tiny reach is weak. This is a different check from problem volume.

### D3. Lever extrapolated from a one-off effect
**Shows up as:** "20 треков дали +5pp → расширим до 50." Linearity assumed; carrier reality ignored (20 don't even fit on screen).
**Expose it:** Where's the evidence the mechanism scales? Does the bigger version even survive contact with the medium (screen, attention, context)?

## E. Coherence of cause → effect across phases

### E1. Solution doesn't test its own hypothesis
**Shows up as:** like-sticker buried in a menu, attached to "more reactions → more posting."
**Expose it:** If this ships and the metric moves (or doesn't), what will we have learned? Does it match the stated hypothesis?

### E2. Solution acts at the wrong phase of the process
**Shows up as:** problem lives at one phase, solution acts at another. "Отмены на этапе 'еду в ресторан' (заказ уже принят) → покажем чаевые ДО принятия."
**Expose it:** Does the lever act at the same phase where the problem occurs? Mismatched phase = the solution can't touch the problem.

### E3. Orphan hypothesis (broken lineage)
**Expose it:** Which quantified opportunity-level hypothesis does this solution/experiment inherit from? If none, why are we doing it?

### E4. One solution fixed before splitting the problem by lever-sensitivity
**Shows up as:** a single solution chosen "for everyone" when the problem actually decomposes into sub-segments with different sensitivities. "Бросают корзину → умная корзина" — but price-sensitive users want a discount, premium users want simplicity.
**Expose it:** Does the problem split by sub-segment, each responsive to a *different* lever (price elasticity vs convenience)? Is the barrier confirmed by qualitative research (custdev), or just asserted ("устают и уходят")?

### E5. Solution destroys a hidden function of the current behavior
**Shows up as:** removing an "inconvenience" that secretly carries value. Long manual basket-building feels like control/trust; auto-fill "as-is" may cause anxiety — improving the barrier metric while regressing an unmeasured need.
**Expose it:** Does the awkward current behavior carry a non-obvious function (control, trust, ritual)? Would the solution kill it? Name the function and check the solution preserves it.

## F. OKR-specific

### F1. Objective with no measurement / lever / metric behind it
**Shows up as:** "стать №1 по качеству рекомендаций" with no way to measure quality, no growth lever, no metric set. Comparative claims ("№1", "лучший") with no shared scale on which the comparison even exists.
**Expose it:** Is there (a) a measurement approach, (b) a clear growth lever, (c) a metric or metric-group? For comparative claims: is there a single scale that ranks players? No → it's a slogan.

### F2. KR measures a mid-chain proxy, not the result the Objective promises
**Shows up as:** Objective about market leadership; KRs about engagement-with-recommendations. Quality can rise while market share / brand perception don't move.
**Expose it:** At what point on the causal chain does the KR sit relative to what the Objective promises? If the Objective is about the end (market), the KR must measure the end (market), not the mechanism's mid-point. Topic-match is not enough; level-match is required.

## G. Verifiability without appeal to authority

### G1. Subjective prioritization laundered as objective (ICE/RICE)
**Shows up as:** an ICE/RICE table with confident scores (7.2 vs 5.1). Looks objective; is collective expert guesswork.
**Expose it:** Where does the number come from — an a-priori basis or a vibe with decimals? **The real test: could someone with little/no context grasp the importance *by meaning*, or must they defer to expertise?** Everything good here is verifiable from the outside — by number+method, operationalization, or a meaning-chain a smart outsider can follow. Anything requiring "trust the expert" is a defect by design.

### F3. KR satisfiable by only one solution (solution leaked into the goal)
**Shows up as:** a KR phrased as the output of a solution already chosen, so the fan of alternatives can't compete. Objective about cooking any recipe today + KR "доля корзин без 'не нашлось' до 80%" — excludes delivery integration, hiding recipes, showing substitutes.
**Why it's a trap:** the OKR is the metric focus at the *entry* of the cycle, over the reachable slice; solutions come *after* and compete under it. Baking one solution into the KR pre-empts discovery.
**Expose it:** Could the whole fan of candidate solutions move this KR, or only one? If only one, it's that solution's output disguised as a goal. Rephrase to the result on the reachable slice (the SOM), e.g. "+31К/мес возвращающихся."

## How to write the critique

For each issue: **flaw → why it matters → what a stronger version requires.** Specific to this artifact. End with the single most important thing to fix before the work proceeds to the next stage.
