# Solution artifact

Answers: **what could move the opportunity, and why should we believe it changes user behavior?** The center of gravity is the *theory of mechanism* — the explicit causal chain. A solution without a stated mechanism is a guess.

## Problem ↔ solution mapping — get this right

Allowed: **one-to-many in either direction, separately.**
- one problem → several candidate solution-hypotheses ✓
- one solution → several problems ✓ (as an observation)

Forbidden as a priority argument: **many problems → one solution.** A solution promoted *because* it hits A and B at once is a focus-blur red flag, not a merit — hitting many problems usually means hitting none precisely. Breadth never earns priority.

## Structure

```
# Solutions for: [opportunity name]

## Наследование от Opportunity
- Потенциал и сегмент, к которым привязано (ссылка/повтор)
- Верхнеуровневая гипотеза, которую решения должны проверять
  (lineage: каждое решение наследует её; orphan-решения вырезаются)

## Карта проблема ↔ решение
one-to-many в одну сторону. НЕ продвигать решение за широту охвата.

## Перед фиксацией решения — две проверки

**1. Расщепляется ли проблема по подсегментам с разной чувствительностью к разным рычагам?**
Одна проблема ("бросают корзину") часто скрывает разные механизмы у разных подсегментов, и под каждый — свой рычаг. Премиум-юзеры утекают из-за неудобства (рычаг: упрощение), ценочувствительные — из-за цены (рычаг: скидка на возврат корзины). Проверь ценовую эластичность и сегментную чувствительность ДО того, как зафиксировать одно решение «на всех». Это и есть содержательная причина one-to-many: много решений, потому что подсегменты реагируют на разные рычаги. И барьер должен быть подтверждён качественным исследованием (custdev), а не постулирован («устают и уходят» — откуда знаем?).

**2. Скрытая функция текущего «неудобного» поведения.**
Прежде чем убирать «издержку», спроси: не несёт ли неудобное поведение неочевидную ценность? Долгая ручная сборка корзины даёт ощущение контроля/доверия; автосборка «в лоб» может его разрушить и вызвать тревогу — то есть улучшить метрику барьера и просесть по неизмеряемой потребности. Решение, оптимизирующее издержку, может сломать скрытую функцию. Назови её и проверь, сохраняет ли решение её.

## Для каждого решения — теория механизма
### Решение: [name]
- Привязано к проблеме(ам): [...]
- Цепочка механизма по звеньям:
  Решение X → меняет поведение Y → потому что верно допущение Z
- Статус каждого звена: proven / disproven / assumed
- Фаза процесса: решение действует в той же фазе, где живёт проблема? (E2)
- Альтернативные объяснения: что ещё дало бы тот же эффект
- Тест на самопроверку: если уедет в прод и метрика двинется (или нет) —
  что узнаем? Совпадает ли с заявленной гипотезой? (E1)
- Объём охвата рычага: на какой доле случаев решение ВООБЩЕ может сработать? (D2)

## Приоритизация
Через quantified-потенциал и силу доказательств. НЕ ICE/RICE.
Тест прозрачности: способен ли человек без контекста понять важность
ПО СМЫСЛУ, а не положившись на экспертный скор? Если нет — переписать. (G1)

## [OPEN]
```

## Gate to pass before Experiment stage

- Map is one-to-many in a single direction; no solution is prioritized for breadth.
- Every solution has an explicit **mechanism chain**, each link status-tagged.
- Each solution acts at the **same process phase** as its problem (E2).
- Each solution passes the **self-test** — shipping it actually tests its hypothesis (E1).
- **Lever reach** is checked, separately from problem volume (D2).
- **Lineage** intact: every solution traces to an opportunity-level hypothesis.
- Prioritization is **outsider-verifiable by meaning**, not by ICE/RICE score.

## The self-test (E1) — canonical failure

Hypothesis: "Если автор получает больше реакций, он постит чаще."
Solution: лайк-стикер в разделе «стикеры» редактора историй.
Fails: даже сработав, проверяет «зрители реагируют больше при новых типах реакций» — *другую* гипотезу; запрятанный в меню — почти ничего. Чтобы проверить исходную, нужно гарантировать рост *полученных* реакций (например, реакция по умолчанию на все истории) и смотреть на частоту постинга автора.

## Phase mismatch (E2) — canonical failure

Problem: курьеры отменяют на этапе "еду в ресторан" (заказ уже принят).
Solution: показ чаевых *до принятия*. Acts one phase too early → cannot touch the cancels it claims to fix.

## Mechanism chain — good vs bad

**Bad:** "Добавим trusted-фильтр → DR вырастет." (no mechanism, no status, no reach)
**Good:** "Trusted-выбор → меньше отмен после акцепта по причине 'долго ждать' → потому что trusted реже стоят на месте (assumed; проверяется сравнением отмен trusted vs остальные). Альт-объяснение: выбирающие trusted сами терпеливее/опытнее — контролировать (A3). Фаза: и проблема, и рычаг на post-accept (E2 ✓). Охват: trusted доступны в [X]% заказов (D2)."
