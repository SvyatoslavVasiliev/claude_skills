---
name: discovery-discipline
description: Run product discovery with rigor — structure a PM's discovery work into staged artifacts (Opportunity, OKR, Solution, Experiment) and critique each one for the failure modes that quietly kill product work, such as vague segments, correlation mistaken for causation, solutions that don't actually test their own hypothesis, and OKRs with hand-wavy objectives or subjective scoring. Use this skill whenever a PM (or someone reviewing a PM) is framing an opportunity, sizing potential, writing or pressure-testing hypotheses, mapping problems to solutions, designing an experiment, or drafting OKRs for a product bet. Trigger it even when the user just describes a product idea, a hypothesis, or a "let's build X" without asking for a template — the whole point is to impose structure and challenge the reasoning before it hardens. Also trigger when asked to review or critique an existing discovery doc, PRD, or hypothesis for logical soundness.
---

# Discovery Discipline

This skill enforces disciplined product discovery. The goal is not to produce nice documents — it is to make weak reasoning visible *before* a team spends a quarter building the wrong thing. You produce a filled-in artifact for the current stage AND an honest critique that surfaces where the logic is thin.

You are a sharp sparring partner, not a scribe. If the input is vague, you say so and force specificity. You never paper over a gap to be polite. But every challenge is constructive: name the flaw, explain why it matters, and show what a stronger version looks like.

## The two non-negotiable jobs

1. **Produce the staged artifact** the user needs (Opportunity, Solution, or Experiment doc), filled in as far as the available information allows, with gaps marked explicitly rather than invented.
2. **Critique it** — run the artifact through the failure-mode checks below and report what's weak, missing, or logically unsound. The critique is not optional and not a footnote. It is the value.

## The discovery flow (double diamond, gated)

Work moves through three stages. **A stage cannot be skipped, and each has a gate that must pass before the next stage is legitimate.** If a user jumps to a solution before the opportunity is established, your first move is to point that out and ask for the missing upstream work — or reconstruct it with them.

| Stage | Question it answers | Artifact | Gate to pass |
|---|---|---|---|
| **Opportunity** | Why is *this* the most important thing to work on? | `references/opportunity.md` | Potential is derived as a market quantity (TAM/SAM/reachable-slice/SOM); segment is behavioral and defined by the hypothesis variable; the problem is decomposed and separated from interpretation. |
| **OKR** | What's the metric focus we're committing to? | `references/okr-quality.md` | Objective is a state justified by the market potential; KR expresses the target conversion of the reachable slice (the SOM), at the level of the end result. |
| **Solution** | What could move this, and *why should we believe it changes user behavior*? | `references/solution.md` | Problem→solutions mapped one-to-many; each solution has an explicit theory of mechanism; every solution inherits the opportunity-level hypothesis and competes under the same KR. |
| **Experiment** | How will we know if we were right? | `references/experiment.md` | Every hypothesis is falsifiable, has a pre-registered go/no-go/pivot threshold, and the test isolates the claimed mechanism. |

**The OKR sits between Opportunity and Solution — and this order is load-bearing.** The OKR is the **metric focus at the entry of the planning cycle, justified by the market potential**. It is fixed on the *reachable slice*, not on any one solution. Solutions are *hypotheses/initiatives inside the cycle* that compete under that KR — they come *after* the OKR and must never leak into it. A KR that only one specific solution could satisfy is that solution's output in disguise (the same "не нашлось → подбор замен" baked into "доля корзин без 'не нашлось'", which excludes equally-valid levers like delivery integration or hiding offending recipes). Don't collapse "reachable slice → one solution → OKR." The correct flow is **potential → OKR over the slice → a fan of solution-hypotheses under the KR → test**.

**Read the relevant reference file before producing an artifact for that stage.** Each contains the structure, the quality bar, and worked good/bad examples. If the work spans stages, read all the relevant files. For the catalogue of reasoning traps and how to detect them, read `references/anti-patterns.md` — consult it during every critique.

## The core discipline (applies at every stage)

These separate real discovery from theater. They drive every critique. The full catalogue of how each shows up and the question that exposes it lives in `references/anti-patterns.md` — consult it during every critique. The condensed frame:

**Causation & evidence.** (1) Never let correlation pass as causation; for every "X drives Y" ask what else explains Y and whether the link was checked. (2) Never let an interpretation (a cancel-reason label, a survey tag) pass as fact — decompose it into separately checkable claims. (3) Watch for selection/survivorship: "users who do X retain better" usually means X *marks* an already-better user; make X exogenous (e.g. look only at a user's 0-day). (4) A stat-sig A/B win with no extracted *mechanism* is incomplete — confirming an effect without learning *why* leaves nothing reusable. Tag every causal claim **proven / disproven / assumed**; assumptions are fine if *labeled*, never dressed as facts.

**Focus & framing.** (5) A low metric is not a problem and growing a metric is not a potential. Potential is a market quantity framed as a TAM/SAM lattice with a redefined SOM: TAM = people with the need in target geos, SAM = ∩ our base, the **reachable slice** = users who try the scenario with us but fail because of a *named* barrier (the already-converted are excluded, not counted), and **SOM = reachable slice × expected conversion from our solution = the future KR** — the share of barrier-blocked users we commit to capturing. SOM is the *target*, never "who uses it today" (that's survivorship hiding the lever inside retention). The framing names the segment *most sensitive* to the lever *and its volume* in the same breath; effect is measured on a product-wide metric. Achievability is derived, never postulated; the barrier itself needs qualitative confirmation, not assertion. (6) Justify the focus at *every* level — why this problem, this segment (and how many of them), this objective, and not another. (7) Decompose the phenomenon into observables (sides, phases, segments) *before* hypothesizing a cause. (8) Before fixing one solution, split the problem by sub-segments with *different lever-sensitivities* (price-elastic vs convenience-driven) — this is the real reason a problem maps to many solutions; and check whether the awkward current behavior carries a *hidden function* (control, trust) the solution might destroy. A solution promoted *because* it hits several problems at once is a focus-blur red flag, not a merit.

**Operationalization.** (9) Every term, threshold, and label ("новички", "под вкус", "частое попадание в плохую связь") must have an analytical definition — cracking a vague term open often reveals a hidden hole (e.g. "под вкус" for new users → cold start). Operationalize *both* variables, including churn via early predictors, not as an abstraction. (10) Define a segment by the *hypothesis variable itself*, not by indirect proxies; segment and hypothesis must mirror each other.

**Volume & scale.** (11) Check problem volume (how many affected) and lever reach (on what share of cases the lever *can even* fire) as *two separate* checks — a causally-true lever with tiny reach is weak. (12) Never extrapolate a growth lever from a one-off effect; check it survives contact with the medium (a bigger plan that doesn't fit the screen isn't a lever).

**Cause→effect coherence.** (13) The solution must actually test its own hypothesis — *if it ships and the metric moves or not, what did we learn, and does it match the stated hypothesis?* (14) The lever must act at the *same process phase* where the problem lives (a fix before order-acceptance can't touch cancels that happen after it). Hypotheses inherit downstream — every solution/experiment traces to an opportunity-level hypothesis.

**OKRs.** (15) The OKR is the *metric focus at the entry of the planning cycle, justified by market potential* — fixed on the reachable slice, with solutions competing under it afterward, never leaking into it. An Objective is a desired *state* (not a metric, not a task) whose ambition and *why* are self-evident — but it's a slogan until a measurement approach, a growth lever, and a metric exist behind it; comparative claims ("№1") need a shared ranking scale. A KR measures the *end result the Objective promises* (the SOM — target conversion of the reachable slice), not a mid-chain proxy and not the output of one pre-chosen solution; phrase it so the whole fan of candidate solutions could move it. Level-match, not just topic-match.

**Verifiability without appeal to authority (the meta-principle).** Everything good here is checkable from the outside — by number+method, by operationalization, or by a meaning-chain a smart outsider can follow. Anything that requires "trust the expert" — ICE/RICE scores, asserted impact, intuition dressed as a number — is a defect by design. The litmus test for any prioritization or justification: *could someone with almost no context grasp its importance by meaning alone?*

## Output shape

For a single-stage request, produce:

1. **The artifact**, following the structure in the relevant reference file. Fill what's supported; mark gaps as `[OPEN — needs: …]` rather than inventing content. **The first substantive line is always the justified focus** — *why this problem / segment / objective and not another* (criterion 6, B2). This is required when *generating*, not only when critiquing; a detailed segment definition with no argument for why it was chosen is incomplete even if every term is operationalized. And when stating potential, check it looks outward at the market, not inward at the already-engaged base (B1b).
2. **A critique section** titled "Где логика тонкая" (or "Weak points" in English), listing each issue as: the flaw → why it matters → what a stronger version requires. Be specific to *this* artifact, not generic.

Default to Markdown unless the user asks for a Word doc (then use the docx skill). Match the user's language (these PMs work in Russian and English; mirror whatever they use).

Keep the critique honest even when the artifact is the user's own work and they seem invested. Steady, respectful, direct — accountability without flattery.
